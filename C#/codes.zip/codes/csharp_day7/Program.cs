﻿using Microsoft.Data.SqlClient;
using MyDataAccessLibrary;
namespace csharp_day7
{
    internal class Program
    {
        static void Main(string[] args)
        {

            DataAccess? da=null;
            try
            {
                da = new DataAccess();
                //foreach loop to iterate through the list
                //foreach (var vehicle in da.GetVehicles())
                //{
                //    Console.WriteLine("Vehicle Id: {0}", vehicle.VehicleId);
                //    Console.WriteLine("Brand: {0}", vehicle.Brand);
                //    Console.WriteLine("Model: {0}", vehicle.Model);
                //    Console.WriteLine("Year: {0}", vehicle.Year);
                //    Console.WriteLine();
                //}
                //input a brand name from the user
                //Console.Write("Enter brand name: ");
                //string? brand = Console.ReadLine();



                //foreach (var vehicle in da.GetVehiclesByBrand(brand))
                //{
                //    Console.WriteLine("Vehicle Id: {0}", vehicle.VehicleId);
                //    Console.WriteLine("Brand: {0}", vehicle.Brand);
                //    Console.WriteLine("Model: {0}", vehicle.Model);
                //    Console.WriteLine("Year: {0}", vehicle.Year);
                //    Console.WriteLine();
                //}

                //da.AddVehicle(67, "Red Bull", "RB2022", 2022);
                da.DeleteVehicles(1);

            }
            catch (SqlException ex) //during production just add catch{}
            {
                Console.WriteLine("Something went wrong");
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.Source);
                Console.WriteLine(ex.StackTrace);

            }
            catch (Exception ex) //during production just add catch{}
            {
                Console.WriteLine("Something went wrong");
                Console.WriteLine( ex.Message);
                Console.WriteLine(ex.Source);
                Console.WriteLine(ex.StackTrace);

            }
            finally
            {
                
                
                da.CloseConnection();
            }
            
        }
    }
}