﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day5
{
    internal class multilevel
    {
        static void Main(string[] args)
        {
            box bw= new boxweight(1,2,3,4);//now we have not used override so this will create an object of the box class 
            bw.ShowDetails();//and now the box.ShowDetails() method is called  try this after removinf overide



        }
    }
   public class box
    {
        private double width, height, depth;
        public box() 
        {
            Console.WriteLine("Paremeter less const Parent");
        }
       public  box(double weight, double height, double depth)
        {
            Console.WriteLine("Parameterized constructor Parent");
            this.height = height;
            this.width = weight;
            this.depth = depth;

        }
        public void Volume()
        {
            Console.WriteLine("Volume is: {0}", (width * height * depth));
        }



        public virtual void ShowDetails()
        {
            Console.WriteLine("W, H and D are: {0}, {1}, {2}(in parent)", width, height, depth);
        }
    }
    class boxweight : box
    {
        public boxweight()
        {
            Console.WriteLine("Paremeter less const child");
        }    
        public double weight;
        public boxweight(double weight,double w,double h,double d):base(w,h,d)//this is sent in the order of whih its given its just mapped to the parent constructor  
        {
            Console.WriteLine("Parameterized constructor child{0}",h);
            this.weight = weight;
        }


         public override void ShowDetails()
        {
            base.ShowDetails();//this will display the showdetails of the parent class
            
            Console.WriteLine("Weight is (in child){0}",weight);
        }
    }
}
