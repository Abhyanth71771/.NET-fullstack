﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day5
{
    internal class overriding
    {
        static void Main(string[] args)
        {
            Shape[] s = new Shape[2];
            s[0] = new Circle();
            s[1] = new Square();//now that I have used overide and virtual this will work unlike the previous code the circle and he square's area will be called
            foreach(Shape shape in s)
            {
                shape.Area();
            }
        }
        class Shape
        {
            public virtual void Area()
            {
                Console.WriteLine("Area of Shape called");
            }
        }
        class Circle : Shape
        {

            public override void Area()
            {
                Console.WriteLine("Area of circle");
            }

        }



        class Square : Shape
        {

            public override void Area()
            {
                Console.WriteLine("Area of square");
            }

        }


    }
}
