﻿namespace csharp_day5
{
    internal class fun_overloading
    {
        static void Main(string[] args)
        {
            sum("hello", "hi");
            sum(1.2, 3.5);
            sum(1, 3);
            Child c = new Child();
            c.ParentBehavior();
        }

        static void sum(int x, int y)
        {
            Console.WriteLine("Int version called");
        }
        static void sum(string x, string y)
        {
            Console.WriteLine("String version called");
        }
        static void sum(double x, double y)
        {
            Console.WriteLine("Double version called");
        } 
        
    }
}