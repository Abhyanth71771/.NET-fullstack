﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day5
{

     class Parent
    {
        public void ParentBehavior()
        {
            Console.WriteLine("This is parent behavior");
        }
    }



    class Child : Parent
    {
        //ParentBehavior() is inherited here
        public void ChildBehavior()
        {
            Console.WriteLine("This is child behavior");
        }
    }
}
