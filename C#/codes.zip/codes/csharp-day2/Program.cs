﻿namespace csharp_day2
{
    internal class Program
    {
        static void Main()
        {
            //typeconversion demo
                //implicit conversion
            int i = 1234;
            long z = i;
            double x = 89.99;
                //explicit conversion-->if that (int) is not given it throws an error
            int j = (int)x;
            //Console.WriteLine(j);
            //using Var 
            double db;
            var v1 = 32.889988;//we have to initialize a value else an error will be thrown
           

        }
    }
}