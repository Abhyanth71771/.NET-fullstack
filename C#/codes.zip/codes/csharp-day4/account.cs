﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day4
{
    internal class account
    {
 
            int accid;
            string name;
            double balance;
            static string bname="Karnataka Bank";
            public account()//same name as the class name
            {
                this.accid = 0;
                this.name = "";
                this.balance = 0.0;

            }
            public account(int id, string name, double balance)//parametrized const 
                                                               //if the parameter is different comparet to the data embers then this. is not required
            {
                accid = id;
                this.name = name;
                this.balance = balance;
            }
            public void Deposit(double amt)
            {
                balance += amt;
                Console.WriteLine("Hello {0} Deposit successfull",name);
            }
            public void withdraw(double amt)
            {
                balance -= amt;
                Console.WriteLine(" Hello {0} Withdraw successfull",name);
            }

            public static string acc ()
            {
            return bname;
            }

            public double CurrentBalance //AutoImplemented Properties
            {
                get;
                set;
            }

            public double GetBalance()
            {
                return balance;
            }
            
        
    }
}
