﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day4
{
    internal class property_demo
    {
        static void Main(string[] args)
        {
            circle circle= new circle();
            circle.CircleRadius = 10;
            
            Console.WriteLine("Area is:{0}", circle.Computearea());
            Console.WriteLine("Circumference is:{0}", circle.Computecircumference());
            Console.WriteLine("Radius is:{0}",circle.CircleRadius);
        }
    }
    class circle
    {
       
        private double area;
        private double circum;

        public double Computearea() 
        {
            return Math.PI * CircleRadius * CircleRadius;
        }
        public double Computecircumference()
        {
            return Math.PI * 2 * CircleRadius;
        }
        //public double CircleRadius
        //{
        //    get { return r; }//accessor or getter
        //    set { r = value; }//mutator or setter
        //}
        public double CircleRadius
        {
            get; set;
        }



    } 
}
