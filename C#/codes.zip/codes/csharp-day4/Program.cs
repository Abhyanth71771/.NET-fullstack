﻿namespace csharp_day4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            account a1=new account();
            account a2=new account(1,"Abhyanth",3000);
            Console.WriteLine(account.acc());
            
            Console.WriteLine("Initial balance of a1: {0}", a1.GetBalance());
            Console.WriteLine("Initial balance of a2: {0}", a2.GetBalance());
            a1.Deposit(10000);
            a2.Deposit(20000);
            Console.WriteLine("Balance of a1 after deposit: {0}", a1.GetBalance());
            Console.WriteLine("Balance of a2 after deposit: {0}", a2.GetBalance());
            a1.withdraw(1400);
            Console.WriteLine("Initial balance of a1: {0}", a1.GetBalance());
        }
    }
}