﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day6
{
    internal class genericclass
    {
        static void Main(string[] args)
        {
            demo<int> d1 = new demo<int>(10);
            int i=d1.GetValue();
            Console.WriteLine(i);
            demo<bool> d2 = new demo<bool>(true);
            int j = d1.GetValue();
            Console.WriteLine(j);

        }
        class demo<T>//we give T here to make the type dynamic now wehn we crete any object we shud give the type inside <> and the datatype given here will be put inplace of T
                     //advantage is no boxing or unboxing are required and we have have multiple datatypes for the same class
        {
            private T o;
            public demo(T o)
            {
                this.o = o;
            }
            public T GetValue()
            {
                return o;
            }

        }
    }
}
