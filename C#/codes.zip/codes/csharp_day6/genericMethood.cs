﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day6
{
    internal class genericMethood
    {
        static void Main(string[] args) 
        {
            Swap(11, 12);
            Swap("hello", "no way");
        }
        public static void Swap<t>(t x, t y)
        {
            Console.WriteLine("Before Swap {0} and {1}", x, y);
            t temp = x;
            x = y;
            y = temp;
            Console.WriteLine("Before Swap {0} and {1}", x, y);
        }
    }

}
