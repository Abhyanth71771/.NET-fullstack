﻿namespace csharp_day6
{
    internal class @abstract
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            patient p= new diabeticpatient();
            p.GiveTreatment();
            p.Discharge();
            Itransform T=new transform();
            T.transform("hello");
   
            transform t1= new transform();  
            transform2 t2= new transform2();
            InvokeTransform(t1,"whohooo");
            InvokeTransform(t2, "ssuppppp");
            Tenent t3=new Tenent();
            t3.payrent();//implicit implementation //even afer adding explicit implementation it called implicit by default 
            //to invike explicit implementation
            IHouse1 h1 = t3;//now in the stack there is alrady a variable called t3 which is pointing to tenent object now when this line gets executed h1 will point t3 and
                            // h1 will search in t1 if theres any implementation of Ihouse1 methoods and runs that 
            h1.payrent();//calls payrent of IHOUSE1
            IHouse2 h2=new Tenent();//if we do this a new obj is created in the heap and its a waste of time so use the code in line number 21 so that all the variables  in the stack points to the same object in the heap
            h2.payrent();//calls payrent of IHOUSE2 
            //this is also runntime polymorphism
        }
        static void InvokeTransform(Itransform somevar, object input)
        {
            somevar.transform(input);
        }
        abstract class patient
        {
            public abstract void GiveTreatment();
            public void Discharge()
            {
                Console.WriteLine("Patient Discharged");
            }
        }
        class diabeticpatient:patient
        {
            public override void GiveTreatment()
            {
                Console.WriteLine("Diabeties Treatment Started");
            }
        }
        class heartpatient : patient
        {
            public override void GiveTreatment()
            {
                Console.WriteLine("Heart Treatment Started");
            }
        }
        interface Itransform //convention to begin the interface names with I
        {
            void transform (object input);//implicitly abstract and public
        }
        interface IHouse1 //convention to begin the interface names with I
        {
            void payrent();//implicitly abstract and public
        }
        interface IHouse2 //convention to begin the interface names with I
        {
            void payrent();//implicitly abstract and public
        }
        class transform : Itransform
        {
            void Itransform.transform(object input)
            {
                Console.WriteLine("Transform1 Called with {0}",input);
            }
        }
        class transform2 : Itransform
        {
            public void transform(object input)
            {
                Console.WriteLine("Transform2 Called with {0}", input);
            }
        }
        class Tenent:IHouse1,IHouse2 
        { 
            public void payrent()
            {
                Console.WriteLine("Rent Paid");
            }
            void IHouse1.payrent()
            {
                Console.WriteLine("Paid via cash");
            }
            void IHouse2.payrent()
            {
                Console.WriteLine("Paid is Check");
            }
        }
        class Tenent1 : IHouse1, IHouse2
        {
            void IHouse1.payrent()
            {
                Console.WriteLine("Paid via cash");
            }
            void IHouse2.payrent()
            {
                Console.WriteLine("Paid is Check");
            }

        }
    }
}