﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day6
{
    internal class NonGeneric
    {
        static void Main(string[] args)
        {
            Demo d = new Demo(34);//this is boxing
            int i=(int)d.GetValue();//this should be done as object cannot be converted to int and boxing and unboxing is a very tedious task and is bad for the memory

        }
        class Demo//non generic class
        {
            private object o;
            public Demo(object o)
            {
                this.o = o;
            }
            public object GetValue()
            {
                return o;
            }
        }
    }
}
