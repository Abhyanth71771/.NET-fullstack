using System;
namespace day1
{
    class Program1
    {
        static void Main()
        {   //writeline goes to the next line write keeps the cursor in the smae line
            Console.WriteLine("Hello from Prog2");
            Console.Write("Hello from Prog2");
            // int age;
            // int p=0;
            // age=p;
            // Console.Write(age);-->works
            // int s;
            // Console.Writeline(s);-->error  as no value is assigned
            
        }
    }   
}
