﻿using System; //root namespace contains most of the classes

namespace day1 //namespace is a keyword class are put inside this multiple classes can be put in this
//here csharp-day1 is also a namespace because it will have many classes in it 
//if there are multiple clases unser one namespace then all the classes run and a. exe file is created 
{
    class Program
    {
        static void Main()
        {
            
                var myList = new List<KeyValuePair<string, int>>();
                myList.Add(new KeyValuePair<string, int>("I", 1));
                myList.Add(new KeyValuePair<string, int>("V", 5));
                myList.Add(new KeyValuePair<string, int>("X", 10));
                myList.Add(new KeyValuePair<string, int>("L", 50));
                myList.Add(new KeyValuePair<string, int>("C", 100));
                myList.Add(new KeyValuePair<string, int>("D", 500));
                myList.Add(new KeyValuePair<string, int>("M", 1000));

            Console.WriteLine(myList[0]);

        }
    }
}
