﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day3
{
    internal class params_out
    {
        static void Main()
        {

            displaynames( "abhyanth", "chirag", "sarthak","anil","manish","suhas");
            returnSquareAndCube(10,out int s,out int c);//the out variables can be anything need not be same as what is passed in the function
            Console.WriteLine("Square is {0} and cube is {1}",s,c);
        }
        static void displaynames(params string[]names)
        {
            foreach(string s in names)
            {
                Console.WriteLine("names is {0}",s);

            }
            Console.WriteLine("Total names passed is {0}",names.Length);
        }
        //static int squareandcube(int num)
        //{ int sq = num * num;
        //    int cu = num * num * num;
        //    //return sq,cu;//error 

        //}
        static void returnSquareAndCube(int num,out int square,out int cube)
        {
            //out acts as a function keyword and we need not specify any return 
            square = num * num;
            cube = num * num * num;

            Console.WriteLine("hello");//this function won terminate untill all the statements are executed
                                       //so the above statement wont terminate the function but just put values int those
                                       //variables which can be accessed outside the function 

        }
        
    }
}
