﻿namespace csharp_day3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[][] jagged = new int[2][];
            jagged[0] = new int[2];
            jagged[1] = new int[3];
            jagged[0][0] = 1000;
            jagged[1][0] = 2000;

            for(int i=0;i<jagged.Length;i++)
            {
                Console.WriteLine("Displaying  values for row number {0}",i);
                for(int j = 0; j < jagged[i].Length;j++)
                {
                    Console.Write("{0}\t", jagged[i][j]);
                }
                Console.WriteLine();
            }
        }
    }
}