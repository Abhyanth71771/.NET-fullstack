﻿using MyCustomClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OvijeetCustomLibrary;
//using greetClass;
using KarthikClassLib;

namespace csharp_day3
{
    internal class UseMyCustomLibrary
    {
        static void Main()
        {
            int result = Calculator.square(10);
            Console.WriteLine(result);
            int result1 = Calculator.cube(20);
            Console.WriteLine(result1);
            OvijeetCustomLibrary.wednesday.wed();

            Console.WriteLine(KarthikClassLib.DemoClass.SayHello());


            

        }
    }
}
