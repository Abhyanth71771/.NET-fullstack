﻿namespace MyCustomClassLibrary
{
    public class Calculator
    {
        public static int square (int number)
        {
            log("Square called");
            return (number*number);
        }
        public static int cube(int number)
        {
            log("Cube called");
            return (number * number*number);
        }
        static void log(string messege)
        {
            Console.WriteLine("Log methood called in My custom class Library");
            Console.WriteLine("logged awesome {0}",messege);
        }
    }
}