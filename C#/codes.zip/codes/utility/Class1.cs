﻿namespace utility
{
    public class Class1
    {
        public static Boolean ispalindrome(String s)
        {
            string revs="";
            for (int i = s.Length - 1; i >= 0; i--) //String Reverse  
            {
                revs += s[i];
            }
            if (revs==s)
            {
                return true;
            }

            return false;
        }
    }
}