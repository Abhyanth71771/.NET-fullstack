﻿namespace csharp_day9
{
    internal class DelegateDemo
    {
        public delegate double ComputeDelegate(double x);

        static void Main(string[] args)
        {
            ComputeDelegate cd = ComputeSquare;
            double ans2 = cd(99);//this will internally call ComputeSquare
            Console.WriteLine("The Square is {0}", ans2);
            double ans = ComputeCube(13);
            Console.WriteLine("The cube is {0}",ans);
            double ans1= ComputeSquare(13);
            Console.WriteLine("The square is {0}", ans1);
            cd = ComputeCube;
            double ans3=cd(99);
            Console.WriteLine("The cube is {0}", ans3);
        }
        static double ComputeSquare(double x)
        {
            return x * x;
        }
        static double ComputeCube(double x)
        { 
            return x*x*x;
        }

    }
}