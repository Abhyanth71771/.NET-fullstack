﻿internal class CallbackDemo
{
    public delegate void SortDelegate();
    static void Main()
    {
        //requirement
        //prompt the user and ask the user which sorting algo to use?
        //invoke the Sort() method now and tell it to call that algo



        Console.Write("Which algo to use? ");
        string algo = Console.ReadLine();



        if (algo == "insertion")
        {
            //tell the Sort() method to invoke InsertionSort() function
            Sort(InsertionSort);
        }
        else if (algo == "bubble")
        {
            //tell the Sort() method to invoke BubbleSort() function
            Sort(BubbleSort);
        }
        else if (algo == "merge")
        {
            //tell the Sort() method to invoke MergeSort() function
            Sort(MergeSort);
        }
    }



    //written by Dev1
    static void Sort(SortDelegate sd)
    {
        //this method must call either BubbleSort, InsertionSort or
        //MergeSort
        sd();
    }



    static void BubbleSort()
    {
        Console.WriteLine("BubbleSort() called");
    }
    static void InsertionSort()
    {
        Console.WriteLine("InsertionSort() called");
    }



    static void MergeSort()
    {
        Console.WriteLine("MergeSort() called");
    }
}