﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Protocols;
using Microsoft.Extensions.Configuration;

namespace MyDataAccessLibrary
{
    public class vehicle
    {
        public int? VehicleId { get; set; }
        public string? Brand { get; set; }
        public string? Model { get; set; }
        public int? Year { get; set; }
    }
    public class DataAccess
    {
        SqlConnection? conn = null;
        SqlCommand? comm = null;
        SqlDataReader? dr = null;
        //open the connection only once and close it when the app terminates
        public DataAccess()
        {
            //create an instance of SqlConnection
            conn = new SqlConnection();



            //read the connection string from the config file
            IConfiguration config = new ConfigurationBuilder()
                        .AddJsonFile("appsettings.json")
                    .Build();



            string? connstring = config.GetConnectionString("mydbconnection");
            Console.WriteLine("Read connection string: {0}", connstring);



            //set the connection string of SqlConnection class
            //conn.ConnectionString = "server=IMCVBCP175-MSL2\\SQLEXPRESS2019;database=freshers2022db;integrated security=true;TrustServerCertificate=True;";     //whatever has been read
            conn.ConnectionString = connstring;



            //open the connection
            conn.Open();
            Console.WriteLine("Connected to SQL Server successfully");

        }
        public void CloseConnection()
        {
            if (conn != null)
            {
                if (conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public List<vehicle> GetVehicles() 
        {
            string sql = "select * from vehicles";
            //create a sqlcommand
            comm=new SqlCommand();
            //specify on which connection the command should work
            comm.Connection= conn;
            //specify the sql command
            comm.CommandText= sql;
            //execute the comand
            dr= comm.ExecuteReader();//sql command is sent to sql and whatever is returned by the sql servr will be taken by the data reader can be used to featch each row one by one 
                                      //mostly used to for firing selecy querry 
          List<vehicle> vehicles = new List<vehicle>();
           while(dr.Read())
            {
                //create a vehicle object
                vehicle vehicle = new vehicle();
                vehicle.VehicleId = (int)dr["vehicleid"];
                vehicle.Brand = dr["brand"].ToString();
                vehicle.Model = dr["model"].ToString();
                vehicle.Year = (int)dr["yr"];
                //add this object into the collection
                vehicles.Add(vehicle);
                
            }
            dr.Close();
           return vehicles;
        }
        public List<vehicle> GetVehiclesByBrand(string brand)
        {
            string sql = "select * from vehicles where brand='" + brand + "'";
            comm = new SqlCommand();
            comm.Connection = conn;
            comm.CommandText = sql;
            dr = comm.ExecuteReader();
            if (dr.HasRows==false)
            {
                Console.WriteLine("No Vehicles found");
            }


            List<vehicle> vehicles = new List<vehicle>();
            while (dr.Read())
            {
                vehicle v = new vehicle();
                v.VehicleId = (int)dr["vehicleid"];
                v.Brand = dr["brand"].ToString();
                v.Model = dr["model"].ToString();
                v.Year = (int)dr["yr"];



                vehicles.Add(v);
            }
            if (vehicles.Count == 0)
            {
                Console.WriteLine("No Vehicles found");
            }
            dr.Close();
            return vehicles;
        }
        public void AddVehicle(int vid,string brand,string model,int year)
        {
            //create a parameterized querry
            string sql = "insert into vehicles values(@vid,@brand,@model,@year)";
            comm = new SqlCommand();
            comm.Connection = conn;
            comm.CommandText = sql;

            //tell sql to map each parameter with the @'s
            comm.Parameters.AddWithValue("@vid", vid);
            comm.Parameters.AddWithValue("@brand", brand);
            comm.Parameters.AddWithValue("@model", model);
            comm.Parameters.AddWithValue("@year", year);
            //execute the querry snd get the no of rows effected
            int recordinserted = comm.ExecuteNonQuery();
            Console.WriteLine("{0} records we Inserted successfully",recordinserted);
        }
        public void DeleteVehicles(int vid)
        {
            string sql = "DELETE FROM vehicles WHERE vehicleid=@vid";
            comm = new SqlCommand();
            comm.Connection = conn;
            comm.CommandText = sql;
            comm.Parameters.AddWithValue("@vid", vid);
            int recordinserted = comm.ExecuteNonQuery();
            Console.WriteLine("{0} records we Deleted successfully", recordinserted);
        }
    }
}