﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Day2_A3
    {
        static void Main(string[] args)
        {
            int r;
            Console.WriteLine("Enter the Radius");
            r=int.Parse(Console.ReadLine());
            compute(r, out double rad, out double circum);
            Console.WriteLine("The area of the circle is:{0}", rad);
            Console.WriteLine("The circumference of the circle is:{0}",circum);
        }
        static  void compute(int r,out double area,out double circumference)
        {
            area=Math.PI*r*r;
            circumference=Math.PI*r*2;
        }
    }
}
