﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Assignment6
    {
        static void Main()
        {
        int[] numbers = { 1, 45, 225, 3536, 43, 754, 2414, 763, 263, 42, 64, 21, 45, 773, 2, 5643, 4321236, 321, 23456, 321123456,4,98,67,34,134,6,7,43,36,29,35,32,31 };
        var results = numbers.Where(x => x % 2 == 0);
            Console.WriteLine("Even Numbers are:");
            foreach (int num in results)
            {
                
                Console.WriteLine("{0}\t\t",num);
            }
        var results1=numbers.Where(x=>x>=10 && x<=40);
            Console.WriteLine("Numbers Between 20 and 40 are:");
            foreach (int num in results1)
            {

                Console.WriteLine("{0}\t\t", num);
            }
            var results2 = numbers.OrderByDescending(x => x);
            Console.WriteLine("Desending Order");
            foreach (int num in results2)
            {

                Console.WriteLine("{0}\t\t", num);
            }

        }

    }
}
