﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Assignment4
    {
        static void Main()
        {
            List<Users1> users = new List<Users1>()
            {
                new Users1() { Id = 2153, Name = "Karthik" },
                new Users1() { Id = 13989, Name = "Thendral" },
                new Users1() { Id = 14050, Name = "Deepa" },
                new Users1() { Id = 13981, Name = "Alekhya" },
                new Users1() { Id = 14126, Name = "Asha" },
                new Users1() { Id = 14064, Name = "Madhu" },
                new Users1() { Id = 13994, Name = "Pratiksha" },
                new Users1() { Id = 13963, Name = "Akhila" },
                new Users1() { Id = 14066, Name = "Manoj" },
                new Users1() { Id = 13980, Name = "Ovijeet" },
                new Users1() { Id = 14074, Name = "Ramireddy" },
                new Users1() { Id = 13965, Name = "Arun" },
                new Users1() { Id = 14087, Name = "Raghul" },
                new Users1() { Id = 14054, Name = "Hassan" },
                new Users1() { Id = 14109, Name = "Sarthak" },
                new Users1() { Id = 14048, Name = "Chirag" },
                new Users1() { Id = 13692, Name = "Abhyanth" },
                new Users1() { Id = 14027, Name = "Ambika" },
                new Users1() { Id = 14111, Name = "Shravani" },
                new Users1() { Id = 14080, Name = "Preetha" },
            };
            //var result=users.OrderByDescending(x => x.Name);
            //Console.WriteLine("Names in Desending Order");
            //foreach (var user in result)
            //{
            //    Console.Write("Employee Id is:{0}\t\t",user.Id);
            //    Console.Write("Employee Name is:{0}", user.Name);
            //    Console.WriteLine();
            //}
            var result1 = users.Where(u => u.Name.StartsWith("K"));
            Console.WriteLine("Names Starting With K");
            foreach (var user in result1)
            {
                Console.Write("Employee Id is:{0}\t\t", user.Id);
                Console.Write("Employee Name is:{0}", user.Name);
                Console.WriteLine();
            }
            var result2=users.Where(u=>u.Name.Length>=9);
            foreach(var user in result2)
            {
                Console.Write("Employee Id is:{0}\t\t", user.Id);
                Console.Write("Employee Name is:{0}", user.Name);
                Console.WriteLine();
            }
        }
    }
    class Users1
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
