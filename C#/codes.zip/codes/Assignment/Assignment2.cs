﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Assignment2
    {
        public static void Main()
        {
            PrintAnything();

        }
        interface Iprint
        {
            string print(string x);
        }
        class document:Iprint
        {
            public  string print(string text)
            {
                return text;
            } 
        }
        class image : Iprint
        {
            public  string print(string text)
            {
                return text;
            }
        }
        public static void  PrintAnything()
        {
            document d= new document();
            Console.WriteLine(d.print("Hello to document"));
            image i= new image();
            Console.WriteLine(i.print("Hello to image"));
        }
    }
}
