﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Assignment3
    {
        static void Main()
        {
            user u1=new user();
            Console.WriteLine("Id of User1:{0} and Password is {1}",user.UserId,u1.Password);
            user u2 = new user("hello123");
            user u3 = new user("asdf");
            user u4 = new user();
            Console.WriteLine("The current value of user id is:{0}",user.UserId);
            //Console.WriteLine("Id of User1:{0} and Password is {1}", u1.getid(), u1.Password);

        }
       

    }
    public class user
    {
        public static int UserId = 0;
        public string Password;
        public user()
        {
            this.Password = "NA";
            UserId++;
        }
        public user(string val)
        {
            UserId++;
            this.Password = val;
        }
        //public int getid()
        //{
        //    return UserId;
        //}
    }

}
