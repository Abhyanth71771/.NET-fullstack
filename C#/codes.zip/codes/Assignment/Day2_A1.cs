﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Day2_A1
    {
        static void Main(string[] args)
        {
            int sum=0;
            int[][] jagged = new int[2][];
            jagged[0] = new int[2];
            jagged[1] = new int[3];

            for (int i = 0; i < jagged.Length; i++)
            {
                Console.WriteLine("Enter The Values For Row Number {0}",i);
                for (int j = 0; j < jagged[i].Length; j++)
                {
                    jagged[i][j] = int.Parse(Console.ReadLine());

                }
               
            }
            for (int i = 0; i < jagged.Length; i++)
            {
                Console.WriteLine("Displaying  values for row number {0}", i);
                for (int j = 0; j < jagged[i].Length; j++)
                {
                    Console.Write("{0}\t", jagged[i][j]);
                    sum = sum + jagged[i][j];
                }
                Console.Write("Sum is{0}",sum);
                Console.WriteLine();
                sum = 0;
            }
        }
    }
}
