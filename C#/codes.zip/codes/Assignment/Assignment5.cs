﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    public delegate string Del(string x);
    internal class Assignment5
    {
        static void Main()
        {
            Del d = Draw;
            Console.WriteLine(d("In draw through Delegate"));
            d += Print;
            Console.WriteLine(d("In Print through Delegate"));

        }
        public static string Draw(string val)
        {
            return val;
        }
        public static string Print(string val)
        {
            return val;
        }
    }
}
