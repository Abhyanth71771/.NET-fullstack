﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using utility;

namespace Assignment
{
    internal class Day2_A4
    {
        static void Main()
        {
            string s;
            Console.WriteLine("Enter a string to check if its palindrome");
            s = Console.ReadLine();
            Console.WriteLine(utility.Class1.ispalindrome(s));
            
            
        }
    }
}
