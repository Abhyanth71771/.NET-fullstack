﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Day2_A2
    {
        static void Main()
        {
            //Console.WriteLine("Enter the number of rows");
            //int rows=int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter the number of Columns");
            //int columns = int.Parse(Console.ReadLine());
            //int[,] rect = new int[rows,columns];
            //for (int i = 0; i < rows; i++)
            //{
            //    Console.WriteLine("Input for Row {0}", i);
            //    for (int j = 0; j < columns; j++)
            //    {
            //        Console.WriteLine("Enter value for row {0} and column{1}", i, j);

            //        rect[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}
            //foreach (int row in rect)
            //{
            //    Console.WriteLine(row);
            //}
            int jagged_rows;
            Console.WriteLine("Enter no of rows for Jagged Array");
            jagged_rows=int.Parse(Console.ReadLine());
            int[][] jagged = new int[jagged_rows][];
            
            for(int i=0;i<jagged_rows;i++)
            {
                Console.WriteLine("Enter the no of columns for row number:{0}",i);
                int jagged_columns=int.Parse(Console.ReadLine());
                jagged[i] = new int[jagged_columns];
                
            }
            for (int i = 0; i < jagged.Length; i++)
            {
                Console.WriteLine("Enter The Values For Row Number {0} and enter {1} numbers", i, jagged[i].Length);
                for (int j = 0; j < jagged[i].Length; j++)
                {
                    jagged[i][j] = int.Parse(Console.ReadLine());

                }


            }
         
            foreach (int[] z in jagged)
            {
                
                foreach (int v in z)
                {
                    Console.Write("{0}\t",v);
                }
            }
        }
    }
}
