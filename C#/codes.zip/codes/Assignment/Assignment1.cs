﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Assignment1
    {
        public static void Main()
        {
            Console.WriteLine("Function call with string");
            swap("hello", "bye");
            Console.WriteLine("Function call with Double");
            swap(34.6756432,687876.98765432345678);
        }
        public static void swap<t>(t str1,t str2)
        {
            Console.WriteLine("Values Befor Swap Value1:{0} and Value2:{1}",str1,str2);
            t temp;
            temp = str1;
            str1 = str2;
            str2 = temp;
            Console.WriteLine("Values After Swap Value1:{0} and Value2{1}", str1, str2);

        }
    }
}
