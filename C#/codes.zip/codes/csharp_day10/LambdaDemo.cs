﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day10
{
    internal class LambdaDemo
    {
        public delegate bool da(int x);
        static void Main()
        {
            int[] x = { 22, 11, 23, 112, 3, 4, 3, 5, 4, 488, 89, 88, 76676 };



            int[] oddnos = AllOdd(x);
            Console.WriteLine("All odd nos.");
            foreach (int num in oddnos)
            {
                Console.WriteLine(num);
            }
            int[] evennos = AllEven(x);
            Console.WriteLine("All Even nos.");
            foreach (int num in evennos)
            {
                Console.WriteLine(num);
            }
            int[] arr = FilterArray(x, (num) => num < 50);

        }
        static int[] AllOdd(int[] src)
        {
            List<int> temp = new List<int>();
            foreach (int x in src)
            {
                if (x % 2 != 0)
                {
                    temp.Add(x);

                }
            }
            return temp.ToArray();
        }
        static int[] AllEven(int[] src)
        {
            List<int> temp = new List<int>();
            foreach (int x in src)
            {
                if (x % 2 == 0)
                {
                    temp.Add(x);

                }
            }
            return temp.ToArray();
        }
        static int[] FilterArray(int[] src,da f)
        {
            {
                List<int> temp = new List<int>();
                foreach (int x in src)
                {
                }
                return temp.ToArray();
            }
        }
    }
}
