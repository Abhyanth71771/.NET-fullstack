﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day10
{
    internal class ExtentionDemo
    {
        static void Main()
        {
            double x = 10.97381892;
            Console.WriteLine(x.Square());
        }

    }
    static class MyExtention
    {
        public static double Square(this double x)//the datatype next to this is the one we have extended and added out custom function
                                                        //this keyword refers to the variable on the left side ade the  on the right side is the value of the type this
        {
            return (x*x);
        }
    }
}
