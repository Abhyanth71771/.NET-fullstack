﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_day10
{
    internal class LINQdemo
    {
        static void Main()
        {
            List<Book> books = new List<Book>()
            {
                new Book(){ BookId = 1, BookName = "B1", Publisher = "P1", Price = 100.00 },
                new Book(){ BookId = 2, BookName = "B6", Publisher = "P6", Price = 200.00 },
                new Book(){ BookId = 3, BookName = "B4", Publisher = "P4", Price = 400.00 },
                new Book(){ BookId = 4, BookName = "B2", Publisher = "P2", Price = 160.00 },
                new Book(){ BookId = 5, BookName = "B3", Publisher = "P3", Price = 180.00 },
                new Book(){ BookId = 6, BookName = "B5", Publisher = "P5", Price = 270.00 },
            };
            var result = books.Where(b => b.Publisher == "P1");
            
            


        }
    }
    class Book
    {
        public int BookId { get; set; }
        public string? BookName { get; set; }
        public string? Publisher { get; set; }
        public double Price { get; set; }
    }
}
