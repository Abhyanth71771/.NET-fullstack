﻿namespace csharp_day10
{
    internal class MulticastDelegates
    {
        public delegate void FileDelegate();
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, User!");
            FileDelegate fd = SaveFile;
            fd += UploadFile;//thihs is add one more address to the delegate its calls in the order in which it was sent
            fd();

        }
        static void SaveFile()
        {
            Console.WriteLine("File saved");
        }
        static void UploadFile()
        {
            Console.WriteLine("File Uploaded");
        }
    }

}